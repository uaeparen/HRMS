import { Component, OnInit } from '@angular/core';

import {Router} from "@angular/router";
import {Jobs} from "../jobservice/jobs";
import {JobsService} from "../jobservice/jobs.service";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  department!: Jobs[];
  searchValue!:  string;

  constructor(private jobsService: JobsService, private router: Router) { }


  ngOnInit(): void {
     this.GetJobList();
  }

   private GetJobList(){
     this.jobsService.getJobList().subscribe(data => {
       this.department = data;
       this.alljob;
     })
   }

  alljob(id: number){
    this.router.navigate(['job-detail/user', id])
  }

}
