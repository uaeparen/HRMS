import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {PriceService} from "../price.service";
import {Price} from "../price";

@Component({
  selector: 'app-price-list',
  templateUrl: './price-list.component.html',
  styleUrls: ['./price-list.component.css']
})
export class PriceListComponent implements OnInit {

  price!: Price[];

  constructor(private priceService: PriceService ,
              private router: Router) {
  }

  ngOnInit(): void {
    this.getPrice();
  }

  private getPrice() {
    this.priceService.getPriceList().subscribe(data => {
      this.price = data;
    });
  }

  updatePrice(id: number) {
    this.router.navigate(['/admin/price/price-update', id]);
  }

  deletePrice(id: number) {
    this.priceService.deletePrice(id).subscribe(data => {
      console.log(data);
      this.getPrice();
    })
  }
}
