import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Language} from "../language/language";
import {Price} from "./price";

@Injectable({
  providedIn: 'root'
})
export class PriceService {

  private baseURL = "http://localhost:8080/api/v1/prices";

  constructor(private httpClient: HttpClient) { }

  getPriceList(): Observable<Price[]>{
    return this.httpClient.get<Price[]>(`${this.baseURL}`);
  }

  createPrice(price: Price): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`, price);
  }

  getPriceById(id: number): Observable<Price>{
    return this.httpClient.get<Price>(`${this.baseURL}/${id}`);
  }

  updatePrice(id: number, price: Price): Observable<Object>{
    return this.httpClient.put(`${this.baseURL}/${id}`, price);
  }

  deletePrice(id: number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }
}
