import { Price } from './price';

describe('Price', () => {
  it('should create an instance', () => {
    expect(new Price()).toBeTruthy();
  });
});
