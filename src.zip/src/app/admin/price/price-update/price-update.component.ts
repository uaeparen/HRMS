import { Component, OnInit } from '@angular/core';
import {Price} from "../price";
import {PriceService} from "../price.service";
import {ActivatedRoute, Router} from "@angular/router";

@Component({
  selector: 'app-price-update',
  templateUrl: './price-update.component.html',
  styleUrls: ['./price-update.component.css']
})
export class PriceUpdateComponent implements OnInit {

  id!: number;
  price: Price = new Price();
  constructor(private priceService: PriceService,
              private route: ActivatedRoute,
              private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    this.priceService.getPriceById(this.id).subscribe(data => {
      this.price = data;
    }, error => console.log(error));
  }

  onSubmit(){
    this.priceService.updatePrice(this.id, this.price).subscribe( data =>{
        this.goToEmployeeList();
      }
      , error => console.log(error));
  }

  goToEmployeeList(){
    this.router.navigate(['/admin/price/price-list']);
  }
}
