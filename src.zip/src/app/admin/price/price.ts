export class Price {
  id!: number;
  title!: string;
  summa!: number;
  total!: number;
  fjobs!: number;
  day!: number;
}
