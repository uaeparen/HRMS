import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {Price} from "../price";
import {PriceService} from "../price.service";

@Component({
  selector: 'app-price-create',
  templateUrl: './price-create.component.html',
  styleUrls: ['./price-create.component.css']
})
export class PriceCreateComponent implements OnInit {


  price: Price = new Price();

  constructor(private priceService: PriceService,
              private router: Router) {
  }

  ngOnInit(): void {
  }

  savePrice() {
    this.priceService.createPrice(this.price).subscribe(data => {
        console.log(data);
        this.goToPriceList();
      },
      error => console.log(error));
  }

  goToPriceList() {
    this.router.navigate(['/admin/price/price-list']);
  }

  onSubmit() {
    console.log(this.price);
    this.savePrice();
  }
}
