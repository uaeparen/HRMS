export class Level {
  id!: number;
  name!: string;
}
