import { Component, OnInit } from '@angular/core';
import {Level} from "../level";
import {LevelService} from "../level.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-level-create',
  templateUrl: './level-create.component.html',
  styleUrls: ['./level-create.component.css']
})
export class LevelCreateComponent implements OnInit {

  level: Level = new Level();

  constructor(private levelService: LevelService,
              private router: Router) {
  }

  ngOnInit(): void {
  }

  savePrice() {
    this.levelService.createLevel(this.level).subscribe(data => {
        console.log(data);
        this.goToPriceList();
      },
      error => console.log(error));
  }

  goToPriceList() {
    this.router.navigate(['/admin/level/level-list']);
  }

  onSubmit() {
    console.log(this.level);
    this.savePrice();
  }

}
