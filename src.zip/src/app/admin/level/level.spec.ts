import { Level } from './level';

describe('Level', () => {
  it('should create an instance', () => {
    expect(new Level()).toBeTruthy();
  });
});
