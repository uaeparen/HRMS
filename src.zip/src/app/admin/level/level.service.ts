import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Level} from "./level";

@Injectable({
  providedIn: 'root'
})
export class LevelService {

  private baseURL = "http://localhost:8080/api/v1/level";

  constructor(private httpClient: HttpClient) { }

  getLevelList(): Observable<Level[]>{
    return this.httpClient.get<Level[]>(`${this.baseURL}`);
  }

  createLevel(level: Level): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`, level);
  }

  getLevelById(id: number): Observable<Level>{
    return this.httpClient.get<Level>(`${this.baseURL}/${id}`);
  }

  updateLevel(id: number, level: Level): Observable<Object>{
    return this.httpClient.put(`${this.baseURL}/${id}`, level);
  }

  deleteLevel(id: number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }
}
