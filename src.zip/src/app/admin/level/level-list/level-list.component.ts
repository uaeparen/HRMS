import { Component, OnInit } from '@angular/core';
import {Department} from "../../department/department";
import {DepartmentService} from "../../department/department.service";
import {Router} from "@angular/router";
import {Level} from "../level";
import {LevelService} from "../level.service";

@Component({
  selector: 'app-level-list',
  templateUrl: './level-list.component.html',
  styleUrls: ['./level-list.component.css']
})
export class LevelListComponent implements OnInit {

  level!: Level[];

  constructor(private levelService: LevelService, private router: Router) {
  }

  ngOnInit(): void {
    this.GetDepartmetList();
  }

  private GetDepartmetList() {
    this.levelService.getLevelList().subscribe(data => {
      this.level = data;
    })
  }

  updateLevel(id: number) {
    this.router.navigate(['/admin/level/level-update', id]);
  }

  deleteLevel(id: number) {
    this.levelService.deleteLevel(id).subscribe(data => {
      console.log(data)
      this.GetDepartmetList();
    })
  }

}
