import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {Level} from "../level";
import {LevelService} from "../level.service";

@Component({
  selector: 'app-level-update',
  templateUrl: './level-update.component.html',
  styleUrls: ['./level-update.component.css']
})
export class LevelUpdateComponent implements OnInit {

  id!: number;
  level: Level = new Level();
  constructor(private levelService: LevelService,
              private route: ActivatedRoute,
              private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    this.levelService.getLevelById(this.id).subscribe(data => {
      this.level = data;
    }, error => console.log(error));
  }

  onSubmit(){
    this.levelService.updateLevel(this.id, this.level).subscribe( data =>{
        this.goToEmployeeList();
      }
      , error => console.log(error));
  }

  goToEmployeeList(){
    this.router.navigate(['/admin/level/level-list']);
  }

}
