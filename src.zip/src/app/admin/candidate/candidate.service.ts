import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Company} from "../company/company";
import {Candidate} from "./candidate";

@Injectable({
  providedIn: 'root'
})
export class CandidateService {

  private baseURL = "http://localhost:8080/api/v1/candidateinfo";

  constructor(private httpClient: HttpClient) {
  }

  getCandidateList(): Observable<Candidate[]> {
    return this.httpClient.get<Candidate[]>(`${this.baseURL}`);
  }

  getCandidateById(id: number): Observable<Candidate> {
    return this.httpClient.get<Candidate>(`${this.baseURL}/${id}`);
  }

  deleteCandidate(id: number): Observable<any> {
    return this.httpClient.delete(`${this.baseURL}/${id}`, {responseType: 'text'});
  }
}
