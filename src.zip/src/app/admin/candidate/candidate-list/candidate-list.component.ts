import { Component, OnInit } from '@angular/core';
import {Company} from "../../company/company";
import {CompanyService} from "../../company/company.service";
import {Router} from "@angular/router";
import {Candidate} from "../candidate";
import {CandidateService} from "../candidate.service";

@Component({
  selector: 'app-candidate-list',
  templateUrl: './candidate-list.component.html',
  styleUrls: ['./candidate-list.component.css']
})
export class CandidateListComponent implements OnInit {

  Candidates!: Candidate[];

  constructor(private candidateService: CandidateService, private router: Router) { }

  ngOnInit(): void {
    this.GetCandidateList();
  }

  private GetCandidateList(){
    this.candidateService.getCandidateList().subscribe(data => {
      this.Candidates = data;
    })
  }

  CandidateDetail(id: number){
    this.router.navigate(['/admin/candidate/candidate-detail', id]);
  }

}
