export class Candidate {
  id!: number;
  username!: string;
}
