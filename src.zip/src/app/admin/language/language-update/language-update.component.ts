import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-language-update',
  templateUrl: './language-update.component.html',
  styleUrls: ['./language-update.component.css']
})
export class LanguageUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
