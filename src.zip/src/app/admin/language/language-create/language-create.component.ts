import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-language-create',
  templateUrl: './language-create.component.html',
  styleUrls: ['./language-create.component.css']
})
export class LanguageCreateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
