export class Language {
}
