import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {Department} from "../department";
import { DepartmentService } from '../department.service';

@Component({
  selector: 'app-department-update',
  templateUrl: './department-update.component.html',
  styleUrls: ['./department-update.component.css']
})
export class DepartmentUpdateComponent implements OnInit {

  id!: number;
  departments: Department = new Department();
  constructor(private departmentService: DepartmentService,
              private route: ActivatedRoute,
              private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    this.departmentService.getDepartmentById(this.id).subscribe(data => {
      this.departments = data;
    }, error => console.log(error));
  }

  onSubmit(){
    this.departmentService.updateDepartment(this.id, this.departments).subscribe( data =>{
        this.goToEmployeeList();
      }
      , error => console.log(error));
  }

  goToEmployeeList(){
    this.router.navigate(['/admin/department/department-list']);
  }

}
