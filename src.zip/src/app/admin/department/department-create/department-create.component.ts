import { Component, OnInit } from '@angular/core';
import {Department} from "../department";
import {DepartmentService} from "../department.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-department-create',
  templateUrl: './department-create.component.html',
  styleUrls: ['./department-create.component.css']
})
export class DepartmentCreateComponent implements OnInit {

  departments: Department = new Department();
  constructor(private departmentService: DepartmentService,
              private router: Router) { }

  ngOnInit(): void {
  }

  saveDepartment(){
    this.departmentService.createDepartment(this.departments).subscribe( data =>{
        console.log(data);
        this.goToDepartmentList();
      },
      error => console.log(error));
  }

  goToDepartmentList(){
    this.router.navigate(['/admin/department/department-list']);
  }

  onSubmit(){
    console.log(this.departments);
    this.saveDepartment();
  }
}
