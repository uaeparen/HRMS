export class Company {
  id!: number;
  description!: string;
  firstname!: string;
  lastname!: string;
  company!: string;
  phone!: string;
  time!: string;
  email!: string;
  address!: string;
  url!: string;
  department!: string;
}
