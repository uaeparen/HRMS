import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {Company} from "../company";
import {CompanyService} from "../company.service";

@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.css']
})
export class CompanyListComponent implements OnInit {

  company!: Company[];

  constructor(private companyService: CompanyService, private router: Router) { }

  ngOnInit(): void {
    this.GetCompanyList();
  }

  private GetCompanyList(){
    this.companyService.getCompanyList().subscribe(data => {
      this.company = data;
    })
  }

  CompanyDetail(id: number){
    this.router.navigate(['/admin/company/company-detail', id]);
  }

  CompanyTrash(id: number){

  }

  // deleteCompany(id: number){
  //   this.companyService.deleteCompany(id).subscribe(data =>
  //   {console.log(data)
  //     this.GetCompanyList();
  //   })
  // }

}
