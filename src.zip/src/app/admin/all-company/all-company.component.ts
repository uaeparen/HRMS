import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-company',
  templateUrl: './all-company.component.html',
  styleUrls: ['./all-company.component.css']
})
export class AllCompanyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
