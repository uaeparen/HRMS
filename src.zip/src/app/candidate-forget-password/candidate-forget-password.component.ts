import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-forget-password',
  templateUrl: './candidate-forget-password.component.html',
  styleUrls: ['./candidate-forget-password.component.css']
})
export class CandidateForgetPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
