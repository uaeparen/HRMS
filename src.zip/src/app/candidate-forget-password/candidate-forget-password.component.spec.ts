import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateForgetPasswordComponent } from './candidate-forget-password.component';

describe('CandidateForgetPasswordComponent', () => {
  let component: CandidateForgetPasswordComponent;
  let fixture: ComponentFixture<CandidateForgetPasswordComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CandidateForgetPasswordComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidateForgetPasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
