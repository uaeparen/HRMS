import { Component, OnInit } from '@angular/core';
import {Jobs} from "../jobservice/jobs";
import {JobsService} from "../jobservice/jobs.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-search-list',
  templateUrl: './search-list.component.html',
  styleUrls: ['./search-list.component.css']
})
export class SearchListComponent implements OnInit {

  Jobs!: Jobs[];

  constructor(private jobsService: JobsService, private router: Router) { }

  ngOnInit(): void {
    this.GetJobsList();
  }

  GetJobsList(){
    this.jobsService.getJobList().subscribe(data => {
      this.Jobs = data;
    });
  }
}
