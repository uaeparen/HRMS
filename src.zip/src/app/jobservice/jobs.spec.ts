import { Jobs } from './jobs';

describe('Jobs', () => {
  it('should create an instance', () => {
    expect(new Jobs()).toBeTruthy();
  });
});
