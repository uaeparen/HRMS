import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Jobs} from "./jobs";

@Injectable({
  providedIn: 'root'
})
export class JobsService {

   private baseURL = "http://localhost:8080/api/v1/job";



  constructor(private httpClient: HttpClient) {
  }



  // getJobList(): Observable<any> {
  //   return this.httpClient.get<Jobs[]>(this.baseURL + 'jobs');
  // }

  getJobList(): Observable<Jobs[]> {
    return this.httpClient.get<Jobs[]>(`${this.baseURL}`);
  }

  createJob(jobs: Jobs): Observable<Object> {
    return this.httpClient.post(`${this.baseURL}`, jobs);
  }

  getJobById(id: number): Observable<Jobs> {
    return this.httpClient.get<Jobs>(`${this.baseURL}/${id}`);
  }

  updateJob(id: number, jobs: Jobs): Observable<Object> {
    return this.httpClient.put(`${this.baseURL}/${id}`, jobs);
  }

  deleteJob(id: number): Observable<any> {
    return this.httpClient.delete(`${this.baseURL}/${id}`, {responseType: 'text'});
  }



}
