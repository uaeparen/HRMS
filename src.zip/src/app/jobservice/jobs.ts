export class Jobs {
  id!: number;
  title!: string;
  description!: string;
  fromsalary!: number;
  tosalary!: number;
  category!: string;
  jobtype!: string;
  level!: string;
  file!: string;
  image!: string;
  language!: string;
  skills!: string;
  address!: string;
  lastUpdate!: Date;
}

export class JobService {
}
