import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {HomeComponent} from "./home/home.component";
import {LoginComponent} from "./login/login.component";
import {RegisterComponent} from "./register/register.component";
import {RegisterCompanyComponent} from "./register-company/register-company.component";
import {CompanyDashboardComponent} from "./company/company-dashboard/company-dashboard.component";
import {LoginCompanyComponent} from "./login-company/login-company.component";
import {LoginAdminComponent} from "./login-admin/login-admin.component";
import {CandidateForgetPasswordComponent} from "./candidate-forget-password/candidate-forget-password.component";
import {CompanyForgetPasswordComponent} from "./company-forget-password/company-forget-password.component";
import {EmployerComponent} from "./employer/employer.component";
import {AllJobsComponent} from "./company/all-jobs/all-jobs.component";
import {ApplicationsComponent} from "./company/applications/applications.component";
import {ChoosePackageComponent} from "./company/choose-package/choose-package.component";
import {JobUpdateComponent} from "./company/job/job-update/job-update.component";
import {JobDetailComponent} from "./company/job/job-detail/job-detail.component";
import {JobCreateComponent} from "./company/job/job-create/job-create.component";
import {PackagesComponent} from "./company/packages/packages.component";
import {PaymentComponent} from "./company/payment/payment.component";
import {PriceComponent} from "./company/price/price.component";
import {ViewedResumeComponent} from "./company/viewed-resume/viewed-resume.component";
import {AdminDashboardComponent} from "./admin/admin-dashboard/admin-dashboard.component";
import { CandidateDetailComponent } from './admin/candidate/candidate-detail/candidate-detail.component';
import {CandidateListComponent} from "./admin/candidate/candidate-list/candidate-list.component";
import {CompanyDetailComponent} from "./admin/company/company-detail/company-detail.component";
import {CompanyListComponent} from "./admin/company/company-list/company-list.component";
import {PriceCreateComponent} from "./admin/price/price-create/price-create.component";
import {PriceListComponent} from "./admin/price/price-list/price-list.component";
import {PriceUpdateComponent} from "./admin/price/price-update/price-update.component";
import {DepartmentCreateComponent} from "./admin/department/department-create/department-create.component";
import {DepartmentUpdateComponent} from "./admin/department/department-update/department-update.component";
import {DepartmentListComponent} from "./admin/department/department-list/department-list.component";
import {EmployeeDetailComponent} from "./admin/employee/employee-detail/employee-detail.component";
import {EmployeeListComponent} from "./admin/employee/employee-list/employee-list.component";
import {CreateResumeComponent} from "./candidate/resume/create-resume/create-resume.component";
import {UpdateResumeComponent} from "./candidate/resume/update-resume/update-resume.component";
import {UpdateDetailComponent} from "./candidate/resume/update-detail/update-detail.component";
import {OptionComponent} from "./candidate/option/option.component";
import {MyappsOptionComponent} from "./candidate/option/myapps-option/myapps-option.component";
import {NewsletterOptionComponent} from "./candidate/option/newsletter-option/newsletter-option.component";
import {ImageOptionComponent} from "./candidate/option/image-option/image-option.component";
import {UnwantedOptionComponent} from "./candidate/option/unwanted-option/unwanted-option.component";
import {AppliedJobsComponent} from "./candidate/applied-jobs/applied-jobs.component";
import {ListResumeComponent} from "./candidate/list-resume/list-resume.component";
import {MessageComponent} from "./candidate/message/message.component";
import { SavedJobsComponent } from './candidate/saved-jobs/saved-jobs.component';
import {CandidateResumeComponent} from "./candidate/candidate-resume/candidate-resume.component";
import {CandidateDashboardComponent} from "./candidate/candidate-dashboard/candidate-dashboard.component";
import {AlertJobsComponent} from "./candidate/alert-jobs/alert-jobs.component";
import {SearchListComponent} from "./search-list/search-list.component";
import {JobDetailUserComponent} from "./job-detail-user/job-detail-user.component";
import {BrowseResumeComponent} from "./browse-resume/browse-resume.component";
import {SearchJobComponent} from "./search-job/search-job.component";
import {LevelListComponent} from "./admin/level/level-list/level-list.component";
import {LevelUpdateComponent} from "./admin/level/level-update/level-update.component";
import {LevelCreateComponent} from "./admin/level/level-create/level-create.component";
import {PayComponent} from "./pay/pay.component";
import {MyprofileComponent} from "./company/myprofile/myprofile.component";


const routes: Routes = [
  {path: '', component: HomeComponent},
  {path: '', component: HomeComponent},
  {path: 'login', component: LoginComponent},
  {path: 'login/admin', component: LoginAdminComponent},
  {path: 'login/company', component: LoginCompanyComponent},
  {path: 'register', component: RegisterComponent},
  {path: 'register/company', component: RegisterCompanyComponent},

  {path: 'employer', component: EmployerComponent},
  {path: 'candidate/forget/password', component: CandidateForgetPasswordComponent},
  {path: 'company/forget/password', component: CompanyForgetPasswordComponent},
  {path: 'search/list', component: SearchListComponent},
  {path: 'job-detail/user/:id', component: JobDetailUserComponent},
  {path: 'browse/resume', component: BrowseResumeComponent},
  {path: 'search/job', component: SearchJobComponent},
  {path: 'employee', component: EmployeeListComponent},


  {path: 'admin/dashboard', component: AdminDashboardComponent},
  {path: 'admin/candidate/candidate-detail/:id', component: CandidateDetailComponent},
  {path: 'admin/candidate/candidate-list', component: CandidateListComponent},
  {path: 'admin/company/company-detail/:id', component: CompanyDetailComponent},
  {path: 'admin/company/company-list', component: CompanyListComponent},
  {path: 'admin/employee/employee-detail/:id', component: EmployeeDetailComponent},
  {path: 'admin/employee/employee-list', component: EmployeeListComponent},
  {path: 'admin/price/price-create', component: PriceCreateComponent},//ready
  {path: 'admin/price/price-list', component: PriceListComponent},//ready
  {path: 'admin/price/price-update/:id', component: PriceUpdateComponent},//ready
  {path: 'admin/department/department-create', component: DepartmentCreateComponent},
  {path: 'admin/department/department-update/:id', component: DepartmentUpdateComponent},//ready
  {path: 'admin/department/department-list', component: DepartmentListComponent},//ready
  {path: 'admin/level/level-create', component: LevelCreateComponent},//ready
  {path: 'admin/level/level-update/:id', component: LevelUpdateComponent},//ready
  {path: 'admin/level/level-list', component: LevelListComponent},//ready


  {path: 'company/dashboard', component: CompanyDashboardComponent},
  {path: 'company/all-jobs', component: AllJobsComponent},
  {path: 'company/job-detail/:id', component: JobDetailComponent},
  {path: 'company/job-create', component: JobCreateComponent},
  {path: 'company/job-update/:id', component: JobUpdateComponent},

  {path: 'company/applications', component: ApplicationsComponent},
  {path: 'company/packages', component: PackagesComponent},
  {path: 'company/choose-package', component: ChoosePackageComponent},
  {path: 'company/viewed-resume', component: ViewedResumeComponent},
  {path: 'company/price', component: PriceComponent},
  {path: 'company/payment/', component: PaymentComponent},
  {path: 'company/payment/pay', component: PayComponent},
  {path: 'company/profile', component: MyprofileComponent},

  {path: 'candidate/dashboard', component: CandidateDashboardComponent},
  {path: 'candidate/alert-jobs', component: AlertJobsComponent},
  {path: 'candidate/applied-jobs', component: AppliedJobsComponent},
  {path: 'candidate/list-resume', component: ListResumeComponent},
  {path: 'candidate/message', component: MessageComponent},
  {path: 'candidate/candidate-resume', component: CandidateResumeComponent},
  {path: 'candidate/saved-jobs', component: SavedJobsComponent},
  {path: 'candidate/new-resume', component: CreateResumeComponent},
  {path: 'candidate/resume-detail/:id', component: UpdateDetailComponent},
  {path: 'candidate/resume-update/:id', component: UpdateResumeComponent},
  {path: 'candidate/options', component: OptionComponent},
  {path: 'candidate/unwanted-option', component: UnwantedOptionComponent},
  {path: 'candidate/image-option', component: ImageOptionComponent},
  {path: 'candidate/newsletter-option', component: NewsletterOptionComponent},
  {path: 'candidate/myapps-option', component: MyappsOptionComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
