export class Payment {
}
