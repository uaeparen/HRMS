import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Resume} from "./resume";

@Injectable({
  providedIn: 'root'
})
export class ResumeService {

  private baseURL = "http://localhost:8080/api/v1/resumecandidate";

  constructor(private httpClient: HttpClient) { }

  getResumeList(): Observable<Resume[]>{
    return this.httpClient.get<Resume[]>(`${this.baseURL}`);
  }

  createResume(resume: Resume): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`, resume);
  }

  getResumeById(id: number): Observable<Resume>{
    return this.httpClient.get<Resume>(`${this.baseURL}/${id}`);
  }

  updateResume(id: number, resume: Resume): Observable<Object>{
    return this.httpClient.put(`${this.baseURL}/${id}`, resume);
  }

  deleteResume(id: number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }

  getGeneratePlaceList(){
    return this.httpClient.get(this.baseURL +'/pdf', {responseType: 'blob'});
  }

}
