import { Resume } from './resume';

describe('Resume', () => {
  it('should create an instance', () => {
    expect(new Resume()).toBeTruthy();
  });
});
