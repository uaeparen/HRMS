export class Resume {
  id!: number;
  candidatename!: string;
  surnamecandidate!: string;
  city!: string;
  nationality!: string;
  gender!: boolean
  birthday!: string;
  position!: string;
  criteria!: string;
  date!: string;

}
