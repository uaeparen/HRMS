import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {Resume} from "../resume";
import {ResumeService} from "../resume.service";

@Component({
  selector: 'app-create-resume',
  templateUrl: './create-resume.component.html',
  styleUrls: ['./create-resume.component.css']
})
export class CreateResumeComponent implements OnInit {

  resume: Resume = new Resume();
  constructor(private resumeService: ResumeService,
              private router: Router) { }

  ngOnInit(): void {
  }

  saveResume(){
    this.resumeService.createResume(this.resume).subscribe( data =>{
        console.log(data);
        this.goToResumeList();
      },
      error => console.log(error));
  }

  goToResumeList(){
    this.router.navigate(['/candidate/list-resume']);
  }

  onSubmit(){
    console.log(this.resume);
    this.saveResume();
  }

}
