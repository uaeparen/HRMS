import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-resume',
  templateUrl: './update-resume.component.html',
  styleUrls: ['./update-resume.component.css']
})
export class UpdateResumeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
