import { Component, OnInit } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Resume} from "../resume";
import {ResumeService} from "../resume.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-update-detail',
  templateUrl: './update-detail.component.html',
  styleUrls: ['./update-detail.component.css']
})
export class UpdateDetailComponent implements OnInit {

  constructor(private resumeService: ResumeService, private router: Router) {
  }

  ngOnInit(): void {
  }


  download(){
  this.resumeService.getGeneratePlaceList().subscribe((data)=>{
    let downloadURL = window.URL.createObjectURL(data)
    let link = document.createElement('a')
    let href= downloadURL;
    link.download = "placeList.pdf";
    link.click();
  })
  }

}
