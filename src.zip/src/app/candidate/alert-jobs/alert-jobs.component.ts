import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alert-jobs',
  templateUrl: './alert-jobs.component.html',
  styleUrls: ['./alert-jobs.component.css']
})
export class AlertJobsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
