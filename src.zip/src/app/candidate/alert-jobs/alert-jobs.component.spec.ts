import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlertJobsComponent } from './alert-jobs.component';

describe('AlertJobsComponent', () => {
  let component: AlertJobsComponent;
  let fixture: ComponentFixture<AlertJobsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AlertJobsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AlertJobsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
