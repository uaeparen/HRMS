import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unwanted-option',
  templateUrl: './unwanted-option.component.html',
  styleUrls: ['./unwanted-option.component.css']
})
export class UnwantedOptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
