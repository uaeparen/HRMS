import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnwantedOptionComponent } from './unwanted-option.component';

describe('UnwantedOptionComponent', () => {
  let component: UnwantedOptionComponent;
  let fixture: ComponentFixture<UnwantedOptionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UnwantedOptionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnwantedOptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
