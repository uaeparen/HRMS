import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewsletterOptionComponent } from './newsletter-option.component';

describe('NewsletterOptionComponent', () => {
  let component: NewsletterOptionComponent;
  let fixture: ComponentFixture<NewsletterOptionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewsletterOptionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewsletterOptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
