import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newsletter-option',
  templateUrl: './newsletter-option.component.html',
  styleUrls: ['./newsletter-option.component.css']
})
export class NewsletterOptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
