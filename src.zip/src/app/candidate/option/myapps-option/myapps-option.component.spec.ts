import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyappsOptionComponent } from './myapps-option.component';

describe('MyappsOptionComponent', () => {
  let component: MyappsOptionComponent;
  let fixture: ComponentFixture<MyappsOptionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyappsOptionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyappsOptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
