import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myapps-option',
  templateUrl: './myapps-option.component.html',
  styleUrls: ['./myapps-option.component.css']
})
export class MyappsOptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
