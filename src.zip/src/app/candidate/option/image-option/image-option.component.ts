import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-image-option',
  templateUrl: './image-option.component.html',
  styleUrls: ['./image-option.component.css']
})
export class ImageOptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
