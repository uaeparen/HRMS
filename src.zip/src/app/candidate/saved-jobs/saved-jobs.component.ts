import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saved-jobs',
  templateUrl: './saved-jobs.component.html',
  styleUrls: ['./saved-jobs.component.css']
})
export class SavedJobsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
