import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-resume',
  templateUrl: './candidate-resume.component.html',
  styleUrls: ['./candidate-resume.component.css']
})
export class CandidateResumeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
