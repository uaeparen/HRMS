import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Resume} from "../resume/resume";
import {Apply} from "./apply";

@Injectable({
  providedIn: 'root'
})
export class ApplyService {

  private baseURL = "http://localhost:8081/api/v1/apply";

  constructor(private httpClient: HttpClient) { }

  getApplyList(): Observable<Apply[]>{
    return this.httpClient.get<Apply[]>(`${this.baseURL}`);
  }

  createApply(apply: Apply): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`, apply);
  }

  getApplyById(id: number): Observable<Apply>{
    return this.httpClient.get<Apply>(`${this.baseURL}/${id}`);
  }

  updateApply(id: number, apply: Apply): Observable<Object>{
    return this.httpClient.put(`${this.baseURL}/${id}`, apply);
  }

  deleteApply(id: number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }
}
