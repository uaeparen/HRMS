export class Apply {
  id!: number;
  companyname!: string;
  date!: string;
  applyjob!: string;
}
