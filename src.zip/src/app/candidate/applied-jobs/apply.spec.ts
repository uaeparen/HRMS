import { Apply } from './apply';

describe('Apply', () => {
  it('should create an instance', () => {
    expect(new Apply()).toBeTruthy();
  });
});
