import { Component, OnInit } from '@angular/core';
import {Resume} from "../resume/resume";
import {ResumeService} from "../resume/resume.service";
import {Router} from "@angular/router";
import {Apply} from "./apply";
import {ApplyService} from "./apply.service";

@Component({
  selector: 'app-applied-jobs',
  templateUrl: './applied-jobs.component.html',
  styleUrls: ['./applied-jobs.component.css']
})
export class AppliedJobsComponent implements OnInit {

  apply!: Apply[];

  constructor(private applyService: ApplyService, private router: Router) {
  }

  ngOnInit(): void {
    this.GetApplyList();
  }

  private GetApplyList() {
    this.applyService.getApplyList().subscribe(data => {
      this.apply = data;
    })
  }

  CVDetail(id: number) {
    this.router.navigate(['/company/job-detail', id]);
  }

  deleteCV(id: number) {
    this.applyService.deleteApply(id).subscribe(data => {
      console.log(data)
      this.GetApplyList();
    })
  }
  downloadCV(id: number){
    return null;
  }

}
