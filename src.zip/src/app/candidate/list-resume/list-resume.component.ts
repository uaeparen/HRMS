import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {Resume} from "../resume/resume";
import {ResumeService} from "../resume/resume.service";

@Component({
  selector: 'app-list-resume',
  templateUrl: './list-resume.component.html',
  styleUrls: ['./list-resume.component.css']
})
export class ListResumeComponent implements OnInit {

  resume!: Resume[];

  constructor(private resumeService: ResumeService, private router: Router) {
  }

  ngOnInit(): void {
    this.GetResumeList();
  }

  private GetResumeList() {
    this.resumeService.getResumeList().subscribe(data => {
      this.resume = data;
    })
  }

  resumeDetail(id: number) {
    this.router.navigate(['/candidate/resume-detail', id]);
  }

  resumeUpdate(id: number) {
    this.router.navigate(['/candidate/resume-update', id]);
  }

  resumeDelete(id: number) {
    this.resumeService.deleteResume(id).subscribe(data => {
      console.log(data)
      this.GetResumeList();
    })
  }

}
