import { Component, OnInit } from '@angular/core';
import {UserService} from "../../_services/user.service";
import {TokenStorageService} from "../../_services/token-storage.service";

@Component({
  selector: 'app-candidate-sidebar',
  templateUrl: './candidate-sidebar.component.html',
  styleUrls: ['./candidate-sidebar.component.css']
})
export class CandidateSidebarComponent implements OnInit {

  private roles: string[] = [];
  content?: string;
  isLoggedIn = false;
  username?: string;

  constructor(private userService: UserService, private tokenStorageService: TokenStorageService) { }

  ngOnInit(): void {
    this.userService.getModeratorBoard().subscribe(
      data => {
        this.content = data;
      },
      err => {
        this.content = JSON.parse(err.error).message;
      }
    );
    this.isLoggedIn = !!this.tokenStorageService.getToken();

    if (this.isLoggedIn) {
      const user = this.tokenStorageService.getUser();
      this.roles = user.roles;

      this.username = user.username;
    }
  }

}
