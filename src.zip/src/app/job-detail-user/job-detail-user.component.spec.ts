import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JobDetailUserComponent } from './job-detail-user.component';

describe('JobDetailUserComponent', () => {
  let component: JobDetailUserComponent;
  let fixture: ComponentFixture<JobDetailUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JobDetailUserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JobDetailUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
