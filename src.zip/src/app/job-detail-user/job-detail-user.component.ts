import { Component, OnInit } from '@angular/core';
import {Job} from "../company/job/job";
import {JobService} from "../company/job/job.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-job-detail-user',
  templateUrl: './job-detail-user.component.html',
  styleUrls: ['./job-detail-user.component.css']
})
export class JobDetailUserComponent implements OnInit {


  all!: Job[];

  constructor(private jobService: JobService, private router: Router) { }


  private GetJobList(){
    this.jobService.getJobList().subscribe(data => {
      this.all = data;
    })
  }


  ngOnInit(): void {
    this.GetJobList();
  }

}
