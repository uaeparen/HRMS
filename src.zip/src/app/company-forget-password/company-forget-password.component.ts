import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-forget-password',
  templateUrl: './company-forget-password.component.html',
  styleUrls: ['./company-forget-password.component.css']
})
export class CompanyForgetPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
