import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from "@angular/common/http";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {authInterceptorProviders} from "./_helpers/auth.interceptor";
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LoginCompanyComponent } from './login-company/login-company.component';
import { LoginAdminComponent } from './login-admin/login-admin.component';
import { RegisterComponent } from './register/register.component';
import { RegisterCompanyComponent } from './register-company/register-company.component';
import { CompanyForgetPasswordComponent } from './company-forget-password/company-forget-password.component';
import { CandidateForgetPasswordComponent } from './candidate-forget-password/candidate-forget-password.component';
import { EmployerComponent } from './employer/employer.component';
import { CompanyDashboardComponent } from './company/company-dashboard/company-dashboard.component';
import { CompanySidebarComponent } from './company/company-sidebar/company-sidebar.component';
import { AllJobsComponent } from './company/all-jobs/all-jobs.component';
import { ApplicationsComponent } from './company/applications/applications.component';
import { ChoosePackageComponent } from './company/choose-package/choose-package.component';
import { PackagesComponent } from './company/packages/packages.component';
import { PaymentComponent } from './company/payment/payment.component';
import { PriceComponent } from './company/price/price.component';
import { ViewedResumeComponent } from './company/viewed-resume/viewed-resume.component';
import { JobCreateComponent } from './company/job/job-create/job-create.component';
import { JobDetailComponent } from './company/job/job-detail/job-detail.component';
import { JobUpdateComponent } from './company/job/job-update/job-update.component';
import { AdminSidebarComponent } from './admin/admin-sidebar/admin-sidebar.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { AllCompanyComponent } from './admin/all-company/all-company.component';
import { PriceCreateComponent } from './admin/price/price-create/price-create.component';
import { PriceUpdateComponent } from './admin/price/price-update/price-update.component';
import { PriceListComponent } from './admin/price/price-list/price-list.component';
import { DepartmentCreateComponent } from './admin/department/department-create/department-create.component';
import { DepartmentUpdateComponent } from './admin/department/department-update/department-update.component';
import { DepartmentListComponent } from './admin/department/department-list/department-list.component';
import { CandidateDetailComponent } from './admin/candidate/candidate-detail/candidate-detail.component';
import { CandidateListComponent } from './admin/candidate/candidate-list/candidate-list.component';
import { CompanyListComponent } from './admin/company/company-list/company-list.component';
import { CompanyDetailComponent } from './admin/company/company-detail/company-detail.component';
import { EmployeeListComponent } from './admin/employee/employee-list/employee-list.component';
import { EmployeeDetailComponent } from './admin/employee/employee-detail/employee-detail.component';
import { LanguageCreateComponent } from './admin/language/language-create/language-create.component';
import { LanguageListComponent } from './admin/language/language-list/language-list.component';
import { LanguageUpdateComponent } from './admin/language/language-update/language-update.component';
import { AlertJobsComponent } from './candidate/alert-jobs/alert-jobs.component';
import { AppliedJobsComponent } from './candidate/applied-jobs/applied-jobs.component';
import { CandidateDashboardComponent } from './candidate/candidate-dashboard/candidate-dashboard.component';
import { CandidateSidebarComponent } from './candidate/candidate-sidebar/candidate-sidebar.component';
import { CandidateResumeComponent } from './candidate/candidate-resume/candidate-resume.component';
import { ListResumeComponent } from './candidate/list-resume/list-resume.component';
import { MessageComponent } from './candidate/message/message.component';
import { OptionComponent } from './candidate/option/option.component';
import { ImageOptionComponent } from './candidate/option/image-option/image-option.component';
import { MyappsOptionComponent } from './candidate/option/myapps-option/myapps-option.component';
import { NewsletterOptionComponent } from './candidate/option/newsletter-option/newsletter-option.component';
import { UnwantedOptionComponent } from './candidate/option/unwanted-option/unwanted-option.component';
import { CreateResumeComponent } from './candidate/resume/create-resume/create-resume.component';
import { UpdateResumeComponent } from './candidate/resume/update-resume/update-resume.component';
import { UpdateDetailComponent } from './candidate/resume/update-detail/update-detail.component';
import { EmployeeComponent } from './employee/employee.component';
import { SearchJobComponent } from './search-job/search-job.component';
import { SearchListComponent } from './search-list/search-list.component';
import { JobDetailUserComponent } from './job-detail-user/job-detail-user.component';
import { BrowseResumeComponent } from './browse-resume/browse-resume.component';
import { LevelListComponent } from './admin/level/level-list/level-list.component';
import { LevelUpdateComponent } from './admin/level/level-update/level-update.component';
import { LevelCreateComponent } from './admin/level/level-create/level-create.component';
import { PayComponent } from './pay/pay.component';
import { SavedJobsComponent } from './candidate/saved-jobs/saved-jobs.component';
import { MyprofileComponent } from './company/myprofile/myprofile.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CandidateSidebarComponent,
    LoginComponent,
    LoginCompanyComponent,
    LoginAdminComponent,
    RegisterComponent,
    RegisterCompanyComponent,
    CompanyForgetPasswordComponent,
    CandidateForgetPasswordComponent,
    EmployerComponent,
    CompanyDashboardComponent,
    CompanySidebarComponent,
    AllJobsComponent,
    ApplicationsComponent,
    ChoosePackageComponent,
    PackagesComponent,
    PaymentComponent,
    PriceComponent,
    ViewedResumeComponent,
    JobCreateComponent,
    JobDetailComponent,
    JobUpdateComponent,
    AdminSidebarComponent,
    AdminDashboardComponent,
    AllCompanyComponent,
    PriceCreateComponent,
    PriceUpdateComponent,
    PriceListComponent,
    DepartmentCreateComponent,
    DepartmentUpdateComponent,
    DepartmentListComponent,
    CandidateDetailComponent,
    CandidateListComponent,
    CompanyListComponent,
    CompanyDetailComponent,
    EmployeeListComponent,
    EmployeeDetailComponent,
    LanguageCreateComponent,
    LanguageListComponent,
    LanguageUpdateComponent,
    AlertJobsComponent,
    AppliedJobsComponent,
    CandidateDashboardComponent,
    CandidateResumeComponent,
    ListResumeComponent,
    MessageComponent,
    OptionComponent,
    ImageOptionComponent,
    MyappsOptionComponent,
    NewsletterOptionComponent,
    UnwantedOptionComponent,
    CreateResumeComponent,
    UpdateResumeComponent,
    UpdateDetailComponent,
    EmployeeComponent,
    SearchJobComponent,
    SearchListComponent,
    JobDetailUserComponent,
    BrowseResumeComponent,
    LevelListComponent,
    LevelUpdateComponent,
    LevelCreateComponent,
    PayComponent,
    SavedJobsComponent,
    MyprofileComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [authInterceptorProviders],
  bootstrap: [AppComponent]
})
export class AppModule {}
