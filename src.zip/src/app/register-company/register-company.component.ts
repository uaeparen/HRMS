import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {AuthService} from "../_services/auth.service";

@Component({
  selector: 'app-register-company',
  templateUrl: './register-company.component.html',
  styleUrls: ['./register-company.component.css']
})
export class RegisterCompanyComponent implements OnInit {

  form: any = {
    username: null,
    firstname: null,
    lastname: null,
    phone: null,
    company: null,
    address: null,
    email: null,
    password: null
  };
  isSuccessful = false;
  isSignUpFailed = false;
  errorMessage = '';

  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
  }

  goToLogin(){
    this.router.navigate(['/login/company']);
  }

  onSubmit(): void {
    const {username, firstname, lastname, phone,  company,  address, email, password } = this.form;

    this.authService.registercompany(username, firstname, lastname, phone,  company,   address,email,  password).subscribe(
      data => {
        console.log(data);
        this.isSuccessful = true;
        this.isSignUpFailed = false;
        this.goToLogin();
      },
      err => {
        this.errorMessage = err.error.message;
        this.isSignUpFailed = true;
      }
    );
  }
}
