import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {Job} from "../job/job";
import {JobService} from "../job/job.service";

@Component({
  selector: 'app-all-jobs',
  templateUrl: './all-jobs.component.html',
  styleUrls: ['./all-jobs.component.css']
})
export class AllJobsComponent implements OnInit {

  all!: Job[];
  searchValue:  any;

  constructor(private jobService: JobService, private router: Router) { }

  ngOnInit(): void {
    this.GetJobList();
  }

  init(): void{
    this.jobService.getJobList().subscribe((response)=>{
    this.all = response;
    });
  }

  Search(){
    if (this.searchValue == ""){
      this.init();
    } else {
      this.all = this.all.filter(data =>{
        return data.title.toLocaleLowerCase().match(this.searchValue.toLocaleLowerCase()),
          data.description.toLocaleLowerCase().match(this.searchValue.toLocaleLowerCase());
      });
    }
  }



  private GetJobList(){
    this.jobService.getJobList().subscribe(data => {
      this.all = data;
    })
  }

  jobDetail(id: number){
    this.router.navigate(['/company/job-detail', id]);
  }

  updateJob(id: number){
    this.router.navigate(['/company/job-update', id]);
  }

  deleteJob(id: number){
    this.jobService.deleteJob(id).subscribe(data =>
    {console.log(data)
      this.GetJobList();
    })
  }
}
