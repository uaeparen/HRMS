import { SearchfilteralljobsPipe } from './searchfilteralljobs.pipe';

describe('SearchfilterPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchfilteralljobsPipe();
    expect(pipe).toBeTruthy();
  });
});
