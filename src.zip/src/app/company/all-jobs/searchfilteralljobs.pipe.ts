import { Pipe, PipeTransform } from '@angular/core';
import {Jobs} from "../../jobservice/jobs";

@Pipe({
  name: 'searchfilteralljobs'
})
export class SearchfilteralljobsPipe implements PipeTransform {

  transform(searchValue: any, jobs: Jobs[]): Jobs[] {

    if (!jobs || !searchValue){
      return  jobs;
    }
    return jobs.filter(jobs =>
      jobs.title.toLocaleLowerCase().includes(searchValue.toLocaleLowerCase()));
  }

}
