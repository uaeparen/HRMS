import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {Job} from "../job";
import {JobService} from "../job.service";
import {Department} from "../../../admin/department/department";
import {DepartmentService} from "../../../admin/department/department.service";

@Component({
  selector: 'app-job-create',
  templateUrl: './job-create.component.html',
  styleUrls: ['./job-create.component.css']
})
export class JobCreateComponent implements OnInit {

  job: Job = new Job();
  category!: Department[];


  constructor(private jobService: JobService,private departmentService: DepartmentService,
              private router: Router) { }

  ngOnInit(): void {
    this.GetJobList();
  }


  private GetJobList(){
    this.departmentService.getDepartmentList().subscribe(data => {
      this.category = data;
    })
  }

  saveJob(){
    this.jobService.createJob(this.job).subscribe( data =>{
        console.log(data);
        console.log(this.category.values);
        this.goToJobList();
      },
      error => console.log(error));
  }

  goToJobList(){
    this.router.navigate(['/company/all-jobs']);
  }

  onSubmit(){
    console.log(this.job);
    this.saveJob();
  }
}





// import { Component, OnInit } from '@angular/core';
// import {Router} from "@angular/router";
// import {Job} from "../job";
// import {JobService} from "../job.service";
// import {Jobtype} from "../../../admin/jobtype/jobtype";
// import {JobtypeService} from "../../../admin/jobtype/jobtype.service";
// import {CategoryService} from "../../../admin/category/category.service";
// import {Category} from "../../../admin/category/category";
//
// @Component({
//   selector: 'app-job-create',
//   templateUrl: './job-create.component.html',
//   styleUrls: ['./job-create.component.css']
// })
// export class JobCreateComponent implements OnInit {
//
//   job: Job = new Job();
//   Jobtype: any;
//   category: Category[] | undefined;
//
//   constructor(private jobService: JobService, private jobtypeService: JobtypeService,private categoryService: CategoryService,
//               private router: Router) { }
//
//   ngOnInit(): void {
//     this.categoryService.getCategoriesList().subscribe(data=>{
//       this.category=data;
//     })
//
//     // this.jobtypeService.getJobTypeList().subscribe((data:any)=>{
//     //   this.Jobtype=data;
//     // })
//   }
//
//
//   saveJob(){
//     this.jobService.createJob(this.job).subscribe( data =>{
//         console.log(data);
//         this.goToJobList();
//       },
//       error => console.log(error));
//   }
//
//   goToJobList(){
//     this.router.navigate(['/company/job/all-jobs']);
//   }
//
//   onSubmit(){
//     console.log(this.job);
//     this.saveJob();
//   }
//
//
// }
