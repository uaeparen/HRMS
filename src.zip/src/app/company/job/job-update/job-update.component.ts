import { Component, OnInit } from '@angular/core';
import {Job} from "../job";
import {JobService} from "../job.service";
import {ActivatedRoute, Router} from "@angular/router";

@Component({
  selector: 'app-job-update',
  templateUrl: './job-update.component.html',
  styleUrls: ['./job-update.component.css']
})
export class JobUpdateComponent implements OnInit {

  id!: number;
  job: Job = new Job();
  constructor(private jobService: JobService,
              private route: ActivatedRoute,
              private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    this.jobService.getJobById(this.id).subscribe(data => {
      this.job = data;
    }, error => console.log(error));
  }

  onSubmit(){
    this.jobService.updateJob(this.id, this.job).subscribe( data =>{
        this.goToEmployeeList();
      }
      , error => console.log(error));
  }

  goToEmployeeList(){
    this.router.navigate(['/company/all-jobs']);
  }
}
