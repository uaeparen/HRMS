export class Job {
  id!: number;
  title!: string;
  description!: string;
  fromsalary!: number;
  tosalary!: number;
  category!: string;
  jobtype!: string;
  level!: string;
  file!: string;
  image!: string;
  language!: string;
  skills!: string;
  address!: string;
  lastUpdate!: Date;
  email!: string;
  phone!: string;

}
