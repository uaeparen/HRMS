export class Counter {
  id!: number;
  counter!: string;
}
