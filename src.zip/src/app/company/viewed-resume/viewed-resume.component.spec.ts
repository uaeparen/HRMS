import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewedResumeComponent } from './viewed-resume.component';

describe('ViewedResumeComponent', () => {
  let component: ViewedResumeComponent;
  let fixture: ComponentFixture<ViewedResumeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewedResumeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewedResumeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
