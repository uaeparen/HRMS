import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewed-resume',
  templateUrl: './viewed-resume.component.html',
  styleUrls: ['./viewed-resume.component.css']
})
export class ViewedResumeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
