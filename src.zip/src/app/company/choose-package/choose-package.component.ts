import { Component, OnInit } from '@angular/core';
import {Price} from "../../admin/price/price";
import {PriceService} from "../../admin/price/price.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-choose-package',
  templateUrl: './choose-package.component.html',
  styleUrls: ['./choose-package.component.css']
})
export class ChoosePackageComponent implements OnInit {

  price!: Price[];

  constructor(private priceService: PriceService ,
              private router: Router) {
  }

  ngOnInit(): void {
    this.getPrice();
  }

  private getPrice() {
    this.priceService.getPriceList().subscribe(data => {
      this.price = data;
    });
  }

  ChoosePrice(id: number) {
    this.router.navigate(['/company/payment', id]);
  }
}
