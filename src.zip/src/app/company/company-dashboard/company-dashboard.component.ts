import { Component, OnInit } from '@angular/core';
import {Department} from "../../admin/department/department";
import {DepartmentService} from "../../admin/department/department.service";
import {Router} from "@angular/router";
import {Counter} from "../counter";
import {CounterService} from "../counter.service";

@Component({
  selector: 'app-company-dashboard',
  templateUrl: './company-dashboard.component.html',
  styleUrls: ['./company-dashboard.component.css']
})
export class CompanyDashboardComponent implements OnInit {

  counter!: Counter[];

  constructor(private counterService: CounterService, private router: Router) {
  }

  ngOnInit(): void {
    this.GetCounterList();
  }

  private GetCounterList() {
    this.counterService.getCounterList().subscribe(data => {
      this.counter = data;
    })
  }

}
