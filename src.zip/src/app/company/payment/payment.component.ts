import { Component, OnInit } from '@angular/core';
import {Department} from "../../admin/department/department";
import {DepartmentService} from "../../admin/department/department.service";
import {ActivatedRoute, Router} from "@angular/router";
import {Company} from "../../admin/company/company";
import {CompanyService} from "../../admin/company/company.service";

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  company: Company = new Company();
  constructor(private companyService: CompanyService,
              private router: Router) { }

  ngOnInit(): void {
  }

  saveDepartment(){
    this.companyService.createCompany(this.company).subscribe( data =>{
        console.log(data);
        this.goToDepartmentList();
      },
      error => console.log(error));
  }

  goToDepartmentList(){
    this.router.navigate(['/company/payment/pay']);
  }

  onSubmit(){
    console.log(this.company);
    this.saveDepartment();
  }

}
