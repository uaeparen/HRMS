import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Department} from "../admin/department/department";
import {Counter} from "./counter";

@Injectable({
  providedIn: 'root'
})
export class CounterService {

  private baseURL = "http://localhost:8080/api/v1/total";

  constructor(private httpClient: HttpClient) { }

  getCounterList(): Observable<Counter[]>{
    return this.httpClient.get<Counter[]>(`${this.baseURL}`);
  }

  createCounter(counter: Counter): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`, counter);
  }

  getCounterById(id: number): Observable<Counter>{
    return this.httpClient.get<Counter>(`${this.baseURL}/${id}`);
  }

  updateCounter(id: number, counter: Counter): Observable<Object>{
    return this.httpClient.put(`${this.baseURL}/${id}`, counter);
  }

  deleteCounter(id: number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }
}
