package portal.online.hrms.jumys.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import portal.online.hrms.jumys.controllers.VacancyController;
import portal.online.hrms.jumys.dto.VacancyResponse;
import portal.online.hrms.jumys.models.Vacancy;

import java.util.List;

@Repository
public interface VacancyRepository extends JpaRepository<Vacancy, Long> {

//    @Query("SELECT COUNT(u) FROM Vacancy u WHERE u.id=?1")
//@Query("SELECT COUNT(u) FROM Vacancy")
//    public List<VacancyController> getJoinInformation();
}
