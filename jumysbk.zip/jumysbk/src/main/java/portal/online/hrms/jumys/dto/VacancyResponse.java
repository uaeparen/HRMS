package portal.online.hrms.jumys.dto;

public class VacancyResponse {
}
