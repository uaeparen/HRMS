package portal.online.hrms.jumys.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;
import portal.online.hrms.jumys.dto.CompanyResponse;
import portal.online.hrms.jumys.exception.ResourceNotFoundException;
import portal.online.hrms.jumys.models.Level;
import portal.online.hrms.jumys.models.User;
import portal.online.hrms.jumys.repository.LevelRepository;
import portal.online.hrms.jumys.repository.UserRepository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")
public class CompanyController {

    @Autowired
    private UserRepository userRepository;


    // get all employees
    @GetMapping("/companyinfo")
    public List<User> getAllUser(){
        return userRepository.findAll();
    }




    // get employee by id rest api
    @GetMapping("/companyinfo/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("price not exist with id :" + id));
        return ResponseEntity.ok(user);
    }


    // delete employee rest api
//    @DeleteMapping("/companyinfo/{id}")
//    public ResponseEntity<Map<String, Boolean>> deleteLevel(@PathVariable Long id){
//        Level level = levelRepository.findById(id)
//                .orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
//
//        levelRepository.delete(level);
//        Map<String, Boolean> response = new HashMap<>();
//        response.put("deleted", Boolean.TRUE);
//        return ResponseEntity.ok(response);
//    }


}
