package portal.online.hrms.jumys.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import portal.online.hrms.jumys.exception.ResourceNotFoundException;
import portal.online.hrms.jumys.models.Level;
import portal.online.hrms.jumys.models.Tarif;
import portal.online.hrms.jumys.repository.LevelRepository;
import portal.online.hrms.jumys.repository.TarifRepository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")
public class LevelController {

    @Autowired
    private LevelRepository levelRepository;


    // get all employees
    @GetMapping("/level")
    public List<Level> getAllLevel(){
        return levelRepository.findAll();
    }

    // create employee rest api
    @PostMapping("/level")
    public Level createLevel(@RequestBody Level level) {
        return levelRepository.save(level);
    }

    // get employee by id rest api
    @GetMapping("/level/{id}")
    public ResponseEntity<Level> getLevelById(@PathVariable Long id) {
        Level level = levelRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("price not exist with id :" + id));
        return ResponseEntity.ok(level);
    }

    // update employee rest api

    @PutMapping("/level/{id}")
    public ResponseEntity<Level> updateLevel(@PathVariable Long id, @RequestBody Level levelDetails){
        Level level = levelRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));

        level.setName(levelDetails.getName());

        Level updatedLevel= levelRepository.save(level);
        return ResponseEntity.ok(updatedLevel);
    }

    // delete employee rest api
    @DeleteMapping("/level/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteLevel(@PathVariable Long id){
        Level level = levelRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));

        levelRepository.delete(level);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return ResponseEntity.ok(response);
    }


}
