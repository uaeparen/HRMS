package portal.online.hrms.jumys.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import portal.online.hrms.jumys.models.ResumeCandidate;

import java.util.Optional;


public interface ResumeResporitory extends JpaRepository<ResumeCandidate, Long> {
//    Optional<ResumeCandidate> findByName(String name);
//    boolean existsByName(String name);
}
