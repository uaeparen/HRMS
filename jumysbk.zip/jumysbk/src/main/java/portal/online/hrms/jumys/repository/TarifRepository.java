package portal.online.hrms.jumys.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import portal.online.hrms.jumys.models.Tarif;

@Repository
public interface TarifRepository  extends JpaRepository<Tarif, Long> {
}
