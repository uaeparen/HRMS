package portal.online.hrms.jumys.models;

import javax.persistence.*;


@Entity
@Table(name="resume_candidate")
public class ResumeCandidate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "candidate_name")
    private String candidatename;

    @Column(name ="candidate_surname")
    private String  surnamecandidate;


    @Column(name ="candidate_city")
    private String  city;

    @Column(name ="candidate_birthday")
    private String  birthday;

    @Column(name ="candidate_nationality")
    private String  nationality;

    @Column(name ="candidate_gender")
    private boolean  gender;
    

//    String TotalCandidate = "SELECT COUNT(*) FROM resume_candidate";

    public ResumeCandidate(){}


    public ResumeCandidate(long id, String candidatename, String surnamecandidate, String city, String birthday, String nationality, boolean gender) {
        super();
        this.candidatename = candidatename;
        this.surnamecandidate = surnamecandidate;
        this.city = city;
        this.birthday = birthday;
        this.nationality = nationality;
        this.gender = gender;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public boolean isGender() {
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCandidatename() {
        return candidatename;
    }

    public void setCandidatename(String candidatename) {
        this.candidatename = candidatename;
    }

    public String getSurnamecandidate() {
        return surnamecandidate;
    }

    public void setSurnamecandidate(String surnamecandidate) {
        this.surnamecandidate = surnamecandidate;
    }
}
