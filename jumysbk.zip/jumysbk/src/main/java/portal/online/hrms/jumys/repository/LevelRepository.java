package portal.online.hrms.jumys.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import portal.online.hrms.jumys.models.Level;

@Repository
public interface LevelRepository extends JpaRepository<Level, Long> {
}
