package portal.online.hrms.jumys.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import portal.online.hrms.jumys.exception.ResourceNotFoundException;
import portal.online.hrms.jumys.models.Tarif;
import portal.online.hrms.jumys.repository.TarifRepository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")
public class PriceController {

    @Autowired
    private TarifRepository tarifRepository;


    // get all employees
    @GetMapping("/prices")
    public List<Tarif> getAllPrice(){
        return tarifRepository.findAll();
    }

    // create employee rest api
    @PostMapping("/prices")
    public Tarif createPrice(@RequestBody Tarif price) {
        return tarifRepository.save(price);
    }

    // get employee by id rest api
    @GetMapping("/prices/{id}")
    public ResponseEntity<Tarif> getPriceById(@PathVariable Long id) {
        Tarif price = tarifRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("price not exist with id :" + id));
        return ResponseEntity.ok(price);
    }

    // update employee rest api

    @PutMapping("/prices/{id}")
    public ResponseEntity<Tarif> updatePrice(@PathVariable Long id, @RequestBody Tarif priceDetails){
        Tarif price = tarifRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));

        price.setTitle(priceDetails.getTitle());
        price.setDay(priceDetails.getDay());
        price.setSumma(priceDetails.getSumma());
        price.setTotal(priceDetails.getTotal());
        price.setFjobs(priceDetails.getFjobs());
//        price.setModeratorList(priceDetails.getModeratorList());

        Tarif updatedPrice= tarifRepository.save(price);
        return ResponseEntity.ok(updatedPrice);
    }

    // delete employee rest api
    @DeleteMapping("/prices/{id}")
    public ResponseEntity<Map<String, Boolean>> deletePrice(@PathVariable Long id){
        Tarif price = tarifRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));

        tarifRepository.delete(price);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return ResponseEntity.ok(response);
    }


}
