package portal.online.hrms.jumys.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
public class Department {
    @Id
    @GeneratedValue
    private int id;
    private String name;
    @Null
    @OneToMany(targetEntity = Vacancy.class,cascade = CascadeType.ALL)
    @JoinColumn(name ="department_fk",referencedColumnName = "id")
    private List<Vacancy> products;
}
