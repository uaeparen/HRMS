package portal.online.hrms.jumys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JumysApplication {

    public static void main(String[] args) {
        SpringApplication.run(JumysApplication.class, args);
    }

}
