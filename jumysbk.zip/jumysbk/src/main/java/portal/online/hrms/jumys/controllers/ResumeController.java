package portal.online.hrms.jumys.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import portal.online.hrms.jumys.exception.ResourceNotFoundException;
import portal.online.hrms.jumys.models.ResumeCandidate;
import portal.online.hrms.jumys.repository.ResumeResporitory;

import javax.servlet.http.HttpServletResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")
public class ResumeController {

    @Autowired
    private ResumeResporitory resumeResporitory;


    @GetMapping("/resumecandidate")
    public List<ResumeCandidate> getAllResumeCandidate() {
        return resumeResporitory.findAll();
    }


    @PostMapping("/resumecandidate")
    public ResumeCandidate createResumeCandidate(@RequestBody ResumeCandidate resumeCandidate) {
        return resumeResporitory.save(resumeCandidate);
    }

    @GetMapping("/resumecandidate/{id}")
    public ResponseEntity<ResumeCandidate> getResumeCandidateById(@PathVariable Long id) {
        ResumeCandidate resumeCandidate = resumeResporitory.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department not exist with id :" + id));
        return ResponseEntity.ok(resumeCandidate);
    }

    @PutMapping("/resumecandidate/{id}")
    public ResponseEntity<ResumeCandidate> updateResumeCandidate(@PathVariable Long id, @RequestBody ResumeCandidate resumeCandidateDetails){
        ResumeCandidate resumeCandidate = resumeResporitory.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));

        resumeCandidate.setCandidatename(resumeCandidateDetails.getCandidatename());
        resumeCandidate.setSurnamecandidate(resumeCandidateDetails.getSurnamecandidate());

        ResumeCandidate updateResumeCandidate = resumeResporitory.save(resumeCandidate);
        return ResponseEntity.ok(updateResumeCandidate);
    }

    // delete employee rest api
    @DeleteMapping("/resumecandidate/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteResumeCandidate(@PathVariable Long id){
        ResumeCandidate resumeCandidate = resumeResporitory.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));

        resumeResporitory.delete(resumeCandidate);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return ResponseEntity.ok(response);
    }


//    @GetMapping("/pdf")
//    public void downloadPdf(HttpServletResponse response){
//        try{
//            Path file = Paths.get(pdfService.generatePlacesPdf().getAbsolutePath());
//            if (Files.exists(file)){
//                response.setContentType("application/pdf");
//                response.addHeader("Content-Disposition", "attachment; filename"+ file.getFileName());
//                Files.copy(file, response.getOutputStream());
//                response.getOutputStream().flush();
//            }
//        } catch (Exception e){
//            e.printStackTrace();
//        }
//    }


}
