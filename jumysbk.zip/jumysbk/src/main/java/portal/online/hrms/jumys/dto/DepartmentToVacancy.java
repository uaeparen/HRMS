package portal.online.hrms.jumys.dto;

import lombok.*;
import portal.online.hrms.jumys.models.Department;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Setter
public class DepartmentToVacancy {

    private Department department;
}
