package portal.online.hrms.jumys.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import portal.online.hrms.jumys.exception.ResourceNotFoundException;
import portal.online.hrms.jumys.models.Vacancy;
import portal.online.hrms.jumys.repository.VacancyRepository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")
public class VacancyController {

    @Autowired
    private VacancyRepository vacancyRepository;

    @GetMapping("/vacancy")
    public List<Vacancy> getAllVacancy() {
        return vacancyRepository.findAll();
    }


    @PostMapping("/vacancy")
    public Vacancy createVacancy(@RequestBody Vacancy vacancy){
        return vacancyRepository.save(vacancy);
    }


    // get employee by id rest api
    @GetMapping("/vacancy/{id}")
    public ResponseEntity<Vacancy> getVacancyById(@PathVariable Long id) {
        Vacancy vacancy = vacancyRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department not exist with id :" + id));
        return ResponseEntity.ok(vacancy);
    }

    // update employee rest api

    @PutMapping("/vacancy/{id}")
    public ResponseEntity<Vacancy> updateVacancy(@PathVariable Long id, @RequestBody Vacancy vacancyDetails){
        Vacancy vacancy = vacancyRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));

        vacancy.setTitle(vacancyDetails.getTitle());
        vacancy.setDescription(vacancyDetails.getDescription());
        vacancy.setFromsalary(vacancyDetails.getFromsalary());
        vacancy.setTosalary(vacancyDetails.getTosalary());

        Vacancy updateVacancy = vacancyRepository.save(vacancy);
        return ResponseEntity.ok(updateVacancy);
    }

    // delete employee rest api
    @DeleteMapping("/vacancy/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteVacancy(@PathVariable Long id){
        Vacancy vacancy = vacancyRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));

        vacancyRepository.delete(vacancy);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return ResponseEntity.ok(response);
    }

//     @GetMapping("/total")
//        public List<VacancyController> getTotal() {
//            return vacancyRepository.getJoinInformation();
//    }

}
