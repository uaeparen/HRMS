package portal.online.hrms.jumys.models;

import javax.persistence.*;


@Entity
@Table(name="tarif_vacancy")
public class Tarif {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "price_title")
    private String title;

    @Column(name ="summa")
    private int  summa;


    @Column(name = "total")
    private int total;


    @Column(name = "featured_jobs")
    private int fjobs;


    @Column(name = "day")
    private int day;

//    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "price")
//    private List<Moderator> moderatorList;


    public Tarif() {

    }

    public Tarif(long id, String title, int summa, int total, int fjobs, int day) {
        this.id = id;
        this.title = title;
        this.summa = summa;
        this.total = total;
        this.fjobs = fjobs;
        this.day = day;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getSumma() {
        return summa;
    }

    public void setSumma(int summa) {
        this.summa = summa;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getFjobs() {
        return fjobs;
    }

    public void setFjobs(int fjobs) {
        this.fjobs = fjobs;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

//    public List<Moderator> getModeratorList() {
//        return moderatorList;
//    }
//
//    public void setModeratorList(List<Moderator> moderatorList) {
//        this.moderatorList = moderatorList;
//    }
}
