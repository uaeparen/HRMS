package portal.online.hrms.jumys.models;

public enum ERole {
	ROLE_CANDIDATE,
    ROLE_COMPANY,
    ROLE_ADMIN
}
