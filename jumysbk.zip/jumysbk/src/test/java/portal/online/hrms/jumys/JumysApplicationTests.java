package portal.online.hrms.jumys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JumysApplicationTests {

    @Test
    void contextLoads() {
    }

}
